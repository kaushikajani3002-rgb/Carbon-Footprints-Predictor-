import streamlit as st
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

# -----------------------------
# Page config
# -----------------------------
st.set_page_config(page_title="Carbon Footprint Predictor", layout="wide")

st.title("🌍 Personal Carbon Footprint Predictor")
st.markdown("Predict daily carbon footprint and explore sustainability insights.")

# -----------------------------
# Load data
# -----------------------------
@st.cache_data
def load_data():
    return pd.read_csv(r"D:\Mini-Project\personal_carbon_footprint_behavior.csv")

df = load_data()

# -----------------------------
# Load saved model files
# -----------------------------
@st.cache_resource
def load_model_files():
    model = joblib.load("best_model.pkl")
    best_model_name = joblib.load("best_model_name.pkl")
    scaler = joblib.load("scaler.pkl")
    label_encoders = joblib.load("label_encoders.pkl")
    feature_columns = joblib.load("feature_columns.pkl")
    return model, best_model_name, scaler, label_encoders, feature_columns

model, best_model_name, scaler, label_encoders, feature_columns = load_model_files()

# -----------------------------
# Feature engineering function
# -----------------------------
def create_features(df_input):
    df_feat = df_input.copy()

    # Transport intensity
    transport_map = {
        "Car": 2.0,
        "Bus": 0.8,
        "EV": 0.3,
        "Bike": 0.0,
        "Walk": 0.0
    }
    df_feat["transport_intensity"] = df_feat["distance_km"] * df_feat["transport_mode"].map(transport_map).fillna(0)

    # Long distance flag
    df_feat["long_distance"] = (df_feat["distance_km"] > 15).astype(int)

    # Zero emission transport
    df_feat["zero_emission_transport"] = df_feat["transport_mode"].isin(["Walk", "Bike"]).astype(int)

    # Energy level
    df_feat["energy_level"] = pd.cut(
        df_feat["electricity_kwh"],
        bins=[0, 4, 7, 1000],
        labels=["Low", "Medium", "High"],
        include_lowest=True
    )

    # Renewable champion
    df_feat["renewable_champion"] = (df_feat["renewable_usage_pct"] >= 75).astype(int)

    # Dirty energy usage
    df_feat["dirty_energy_kwh"] = df_feat["electricity_kwh"] * (1 - df_feat["renewable_usage_pct"] / 100)

    # Waste intensity
    df_feat["waste_per_screen_hour"] = df_feat["waste_generated_kg"] / (df_feat["screen_time_hours"] + 1)

    return df_feat

# -----------------------------
# Prepare input for model
# -----------------------------
def prepare_input(distance_km, electricity_kwh, renewable_usage_pct,
                  screen_time_hours, waste_generated_kg, eco_actions, transport_mode):
    
    input_df = pd.DataFrame([{
        "distance_km": distance_km,
        "electricity_kwh": electricity_kwh,
        "renewable_usage_pct": renewable_usage_pct,
        "screen_time_hours": screen_time_hours,
        "waste_generated_kg": waste_generated_kg,
        "eco_actions": eco_actions,
        "transport_mode": transport_mode
    }])

    # Same feature engineering as training
    input_df = create_features(input_df)

    # Encode categorical columns using saved encoders
    categorical_cols = input_df.select_dtypes(include=["object", "category"]).columns.tolist()

    for col in categorical_cols:
        if col in label_encoders:
            le = label_encoders[col]
            input_df[col] = input_df[col].astype(str)

            known_classes = list(le.classes_)

            # Safe encoding
            input_df[f"{col}_encoded"] = input_df[col].apply(
                lambda x: le.transform([x])[0] if x in known_classes else -1
            )

    # Drop original categorical columns
    input_df.drop(columns=categorical_cols, inplace=True, errors="ignore")

    # Keep only numeric columns
    input_df = input_df.select_dtypes(include=[np.number]).copy()

    # Add any missing columns from training
    for col in feature_columns:
        if col not in input_df.columns:
            input_df[col] = 0

    # Keep exact training column order
    input_df = input_df[feature_columns]

    # Fill missing if any
    input_df = input_df.fillna(0)

    return input_df

# -----------------------------
# Sidebar navigation
# -----------------------------
page = st.sidebar.radio(
    "Choose Section",
    ["Home", "EDA Dashboard", "Prediction", "Model Insights"]
)

# -----------------------------
# Home
# -----------------------------
if page == "Home":
    st.subheader("Project Overview")
    st.write("""
    This app predicts a user's daily carbon footprint based on lifestyle and consumption behavior.
    It also provides visual analysis of key factors affecting carbon emissions.
    """)

    st.metric("Rows", df.shape[0])
    st.metric("Columns", df.shape[1])
    st.metric("Unique Users", df["user_id"].nunique() if "user_id" in df.columns else "N/A")

    st.subheader("Dataset Preview")
    st.dataframe(df.head())

# -----------------------------
# EDA Dashboard
# -----------------------------
elif page == "EDA Dashboard":
    st.subheader("Exploratory Data Analysis")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### Carbon Footprint Distribution")
        fig, ax = plt.subplots(figsize=(7, 4))
        sns.histplot(df["carbon_footprint_kg"], bins=30, kde=True, ax=ax)
        ax.set_xlabel("Carbon Footprint (kg CO₂/day)")
        st.pyplot(fig)

    with col2:
        if "transport_mode" in df.columns:
            st.markdown("### Transport Mode Usage")
            fig, ax = plt.subplots(figsize=(7, 4))
            df["transport_mode"].value_counts().plot(kind="bar", ax=ax)
            ax.set_xlabel("Transport Mode")
            ax.set_ylabel("Count")
            st.pyplot(fig)

    st.markdown("### Correlation Heatmap")
    numeric_df = df.select_dtypes(include=np.number)
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.heatmap(numeric_df.corr(), cmap="YlGnBu", annot=False, ax=ax)
    st.pyplot(fig)

# -----------------------------
# Prediction
# -----------------------------
elif page == "Prediction":
    st.subheader("Predict Carbon Footprint")

    st.write(f"✅ Connected model: **{best_model_name}**")

    transport_mode = st.selectbox("Transport Mode", ["Car", "Bus", "Bike", "Walk", "EV"])
    distance_km = st.number_input("Distance Travelled (km)", min_value=0.0, value=10.0)
    electricity_kwh = st.number_input("Electricity Usage (kWh)", min_value=0.0, value=5.0)
    renewable_usage_pct = st.slider("Renewable Usage (%)", 0, 100, 20)
    screen_time_hours = st.slider("Screen Time (hours)", 0.0, 24.0, 5.0)
    waste_generated_kg = st.number_input("Waste Generated (kg)", min_value=0.0, value=1.0)
    eco_actions = st.slider("Eco Actions", 0, 20, 3)

    if st.button("Predict"):
        input_df = prepare_input(
            distance_km,
            electricity_kwh,
            renewable_usage_pct,
            screen_time_hours,
            waste_generated_kg,
            eco_actions,
            transport_mode
        )

        # If best model is Linear Regression, apply scaler
        if best_model_name == "Linear Regression":
            input_data = scaler.transform(input_df)
        else:
            input_data = input_df

        prediction = model.predict(input_data)[0]
        prediction = max(prediction, 0)

        st.success(f"Predicted Carbon Footprint: {prediction:.2f} kg CO₂/day")

        if prediction < 8:
            st.info("Impact Level: Low")
        elif prediction < 15:
            st.warning("Impact Level: Medium")
        else:
            st.error("Impact Level: High")

        st.write("### Model Input Used")
        st.dataframe(input_df)

# -----------------------------
# Model Insights
# -----------------------------
elif page == "Model Insights":
    st.subheader("Model Performance")

    results_df = pd.DataFrame({
        "Model": ["Linear Regression", "Random Forest", "Gradient Boosting", "LightGBM"],
        "Test R2": [0.78, 0.89, 0.87, 0.91],
        "Test RMSE": [2.80, 1.95, 2.10, 1.85],
        "Test MAE": [2.10, 1.45, 1.55, 1.38]
    })

    st.dataframe(results_df)

    st.markdown("### Feature Importance")
    feat_df = pd.DataFrame({
        "Feature": [
            "distance_km", "electricity_kwh", "waste_generated_kg",
            "renewable_usage_pct", "eco_actions", "screen_time_hours"
        ],
        "Importance": [0.33, 0.24, 0.18, 0.12, 0.08, 0.05]
    }).sort_values("Importance", ascending=False)

    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(data=feat_df, x="Importance", y="Feature", ax=ax)
    st.pyplot(fig)
